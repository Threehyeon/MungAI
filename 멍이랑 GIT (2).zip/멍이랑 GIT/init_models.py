import torch
import whisper
import torchaudio
from zonos.model import Zonos
from transformers import AutoTokenizer, AutoModelForCausalLM, AutoModelForSequenceClassification

# 디바이스 설정
device = "cuda" if torch.cuda.is_available() else "cpu"

# Whisper 모델 로드
whisper_model = whisper.load_model("small", device=device)

# KoBERT 감정 분석 모델 로드 (3-class, 8-class)
kobert3_tokenizer = AutoTokenizer.from_pretrained("monologg/kobert", trust_remote_code=True)
kobert3_model = AutoModelForSequenceClassification.from_pretrained("beomi/KcELECTRA-base", num_labels=3).to("cpu")

kobert8_tokenizer = AutoTokenizer.from_pretrained("beomi/KcELECTRA-base")
kobert8_model = AutoModelForSequenceClassification.from_pretrained("beomi/KcELECTRA-base", num_labels=8).to("cpu")

# Polyglot-ko LLM (1.3B) 로드
tokenizer = AutoTokenizer.from_pretrained("heegyu/polyglot-ko-1.3b-chat")
llm = AutoModelForCausalLM.from_pretrained("heegyu/polyglot-ko-1.3b-chat", torch_dtype=torch.float16).to(device)

# TTS 모델 로드
config_path = "/mnt/c/Users/leesh/Desktop/zonos tts py/config.json"
model_path = "/mnt/c/Users/leesh/Desktop/zonos tts py/model.safetensors"
ref_wav = "/mnt/c/Users/leesh/Desktop/zonos tts py/new/girl1.wav"
zonos_model = Zonos.from_local(config_path, model_path, backbone="mamba").eval().cuda()
zonos_model = zonos_model.to(dtype=torch.bfloat16)



# 화자 임베딩 생성
ref_wav_tensor, ref_sr = torchaudio.load(ref_wav)
speaker_embedding = zonos_model.make_speaker_embedding(ref_wav_tensor, ref_sr)

# LLM 예열 (초기 토큰 로딩)
_ = llm(**tokenizer("안녕하세요", return_tensors="pt").to(device))
