import asyncio
from datetime import datetime
from app.utils.db_utils import get_reminders_for_user, get_all_session_ids
from app.services.tts_service import generate_tts


def is_time_close(time1_str, time2_str, delta_minutes=1):
    try:
        time1 = datetime.strptime(time1_str.strip(), "%H:%M")
        time2 = datetime.strptime(time2_str.strip(), "%H:%M")
        return abs((time1 - time2).total_seconds()) <= delta_minutes * 60
    except:
        return False


async def run_reminder_scheduler():
    while True:
        now = datetime.now()
        current_time = now.strftime("%H:%M")
        current_date = now.strftime("%Y-%m-%d")

        session_ids = get_all_session_ids()

        for session_id in session_ids:
            reminders = get_reminders_for_user(session_id)

            for r in reminders:
                if is_time_close(r["time_slot"], current_time):
                    if r.get("start_date") <= current_date <= r.get("end_date"):
                        text = f"현재 시각은 {current_time}입니다. 지금은 {r['drug_name']}을(를) 복용할 시간이에요."
                        try:
                            await generate_tts(session_id=session_id, text=text)
                        except:
                            pass  # 오류 무시
        await asyncio.sleep(60)
