1.
routes — API 엔드포인트(Controller 역할)

포함된 파일들

admin.py — 관리자 관련 API

auth.py — 로그인/토큰 등 인증 API

chat.py — 챗봇 대화 요청 처리

llm_response.py — LLM 모델 응답 생성 엔드포인트

ref_wav.py — 참고 음성(ref wav) 업로드/관리

reminder.py — 리마인더 관련 API

speaker_upload.py — 감정/스피커 데이터 업로드

tts.py — 일반 TTS 요청 엔드포인트

tts_chat.py — TTS + 대화 결합 요청 처리

tts_reminder.py — TTS로 리마인더 읽어주는 API

upload.py — 일반 파일 업로드

voice.py — 음성 분석, 음성 처리 API

voice_upload.py — 음성 파일 업로드

whisper.py — Whisper 음성 인식 엔드포인트

2.
services — 실제 로직이 담긴 핵심 엔진 역할 폴더

포함된 파일들

chatbot_service.py
→ 대화 응답 생성, 톤 조절, 감정 기반 응답 로직

emotion_service.py
→ 감정 분석 로직, 음성·텍스트 감정 처리

tts_service.py
→ TTS 모델 실행(Zonos TTS 등), 음성 생성 처리

tts_utils.py
→ TTS 관련 유틸 함수(음성 후처리 등)

whisper_service.py
→ Whisper ASR 모델 실행, 음성 → 텍스트 변환

3.
utils — 공통 기능 모음

서비스들이 공통으로 사용하는 기능들을 분리해둔 폴더.

포함된 파일들

database.py
→ DB 연결 설정 및 세션 관리

db_utils.py
→ CRUD 작업 등 DB 편의 함수

file_utils.py
→ 파일 저장, 경로 관리, 파일 삭제 등

history_utils.py
→ 대화 기록 저장 관련 유틸

scheduler.py
→ 알림/리마인더 예약 실행 로직(백그라운드 스케줄러)

4.
init_models.py
서버가 시작될 때 필요한 AI 모델들을 미리 로드하고 초기화하는 파일

