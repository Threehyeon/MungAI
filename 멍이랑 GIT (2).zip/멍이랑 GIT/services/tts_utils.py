# app/services/tts_utils.py
import os
import torch

EMBEDDING_DIR = "app/cache/embeddings"
os.makedirs(EMBEDDING_DIR, exist_ok=True)

def get_cached_embedding(session_id):
    path = os.path.join(EMBEDDING_DIR, f"{session_id}.pt")
    if os.path.exists(path):
        return torch.load(path, map_location="cuda")
    return None

def save_embedding(session_id, embedding):
    path = os.path.join(EMBEDDING_DIR, f"{session_id}.pt")
    torch.save(embedding.detach().cpu(), path)
