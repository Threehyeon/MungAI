from fastapi import APIRouter, UploadFile, Form
import os
import torchaudio
import torch
from app.models.init_models import zonos_model

router = APIRouter()

speaker_embedding_cache = {}

@router.post("/upload-ref-wav")
async def upload_ref_wav(file: UploadFile, session_id: str = Form(...)):
    save_dir = "./ref_voices"
    os.makedirs(save_dir, exist_ok=True)
    save_path = os.path.join(save_dir, f"{session_id}.wav")

    with open(save_path, "wb") as f:
        f.write(await file.read())

    # 화자 임베딩 생성
    audio_tensor, sr = torchaudio.load(save_path)
    embedding = zonos_model.make_speaker_embedding(audio_tensor, sr)
    speaker_embedding_cache[session_id] = embedding.to(dtype=torch.bfloat16)

    return {"status": "success", "session_id": session_id}
