# 📂 app/routes/voice.py
from fastapi import APIRouter, UploadFile, Form
import os
import shutil
import ffmpeg  

router = APIRouter()

@router.post("/upload-ref-wav")
async def upload_ref_wav(file: UploadFile, session_id: str = Form(...)):
    try:
        ref_dir = "ref_voices"
        embed_dir = "app/cache/embeddings"
        os.makedirs(ref_dir, exist_ok=True)
        os.makedirs(embed_dir, exist_ok=True)

        # 1. 업로드 파일 저장 (확장자 무시하고 temp로 저장)
        temp_path = os.path.join(ref_dir, f"{session_id}_temp")
        with open(temp_path, "wb") as f:
            shutil.copyfileobj(file.file, f)

        # 2. ffmpeg 변환
        final_path = os.path.join(ref_dir, f"{session_id}.wav")
        ffmpeg.input(temp_path).output(final_path).run(overwrite_output=True)
        os.remove(temp_path)

        # 3. 기존 임베딩 제거
        embedding_path = os.path.join(embed_dir, f"{session_id}.pt")
        if os.path.exists(embedding_path):
            os.remove(embedding_path)

        return {"success": True, "message": "ref_wav 저장 및 변환 완료"}
    except Exception as e:
        print("[ERROR][UPLOAD REF WAV]", e)
        return {"success": False, "message": str(e)}