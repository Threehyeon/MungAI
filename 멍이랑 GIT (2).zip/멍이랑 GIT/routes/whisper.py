from fastapi import APIRouter, UploadFile, Form, BackgroundTasks, HTTPException
from fastapi.responses import JSONResponse
import os, uuid
from app.services.whisper_service import handle_whisper_background

router = APIRouter()

@router.post("/whisper")
async def whisper_handler(
    background_tasks: BackgroundTasks,
    file: UploadFile,
    session_id: str = Form(None),
    timestamp: str = Form(...),
):
    if not session_id:
        session_id = str(uuid.uuid4())[:8]
        print(f"[SERVER] 새 session_id 생성: {session_id}")
    else:
        print(f"[SERVER] 기존 session_id 사용: {session_id}")

    file_path = f"uploaded_{session_id}.wav"
    with open(file_path, "wb") as f:
        f.write(await file.read())

    background_tasks.add_task(handle_whisper_background, file_path, session_id, timestamp)

    return JSONResponse(content={"message": "Whisper 추론 중...", "session_id": session_id})