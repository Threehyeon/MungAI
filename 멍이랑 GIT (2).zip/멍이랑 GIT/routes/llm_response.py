from fastapi import APIRouter, HTTPException
from fastapi.responses import JSONResponse
import os

router = APIRouter()

@router.get("/llm-response")
async def get_llm_response(session_id: str, timestamp: str):
    path = f"llm_outputs/{session_id}_{timestamp}.txt"
    if not os.path.exists(path):
        raise HTTPException(status_code=404, detail="응답 아직 생성되지 않음")

    with open(path, "r", encoding="utf-8") as f:
        response = f.read()
    return JSONResponse(content={"response": response})
