# app/routes/voice.py 또는 voice_upload.py (라우터용)
from fastapi import APIRouter, UploadFile, Form
import os
import shutil

router = APIRouter()

@router.post("/upload-ref-wav")
async def upload_ref_wav(file: UploadFile, session_id: str = Form(...)):
    try:
        ref_dir = "ref_voices"
        embed_dir = "app/cache/embeddings"
        os.makedirs(ref_dir, exist_ok=True)
        os.makedirs(embed_dir, exist_ok=True)

        # 저장
        file_path = os.path.join(ref_dir, f"{session_id}.wav")
        with open(file_path, "wb") as f:
            shutil.copyfileobj(file.file, f)

        # 기존 임베딩 제거
        embedding_path = os.path.join(embed_dir, f"{session_id}.pt")
        if os.path.exists(embedding_path):
            os.remove(embedding_path)

        return {"success": True, "message": "ref_wav 저장 및 임베딩 리셋 완료"}
    except Exception as e:
        print("[ERROR][UPLOAD REF WAV]", e)
        return {"success": False, "message": str(e)}
