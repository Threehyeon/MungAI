from fastapi import APIRouter, UploadFile, Form
from fastapi.responses import JSONResponse
import os
import shutil

router = APIRouter()
REF_DIR = "ref_voices"
os.makedirs(REF_DIR, exist_ok=True)

@router.post("/upload-ref-wav")
async def upload_ref_wav(file: UploadFile, session_id: str = Form(...)):
    try:
        save_path = os.path.join(REF_DIR, f"{session_id}.wav")

        with open(save_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)

        return JSONResponse(content={"success": True, "message": "파일 업로드 완료"}, status_code=200)
    except Exception as e:
        print("[ERROR][UPLOAD REF WAV]", e)
        return JSONResponse(content={"success": False, "message": "파일 업로드 실패"}, status_code=500)
