import sqlite3
import ast  # 문자열로 저장된 리스트를 다시 리스트로 변환

def init_reminder_db():
    conn = sqlite3.connect("reminder.db")
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS reminders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT,
            message TEXT,
            times TEXT,  -- 예: "['08:00', '18:00']"
            start_date TEXT,
            end_date TEXT,
            voice_type TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    conn.close()


def get_reminders_for_user(session_id: str):
    conn = sqlite3.connect("reminder.db")
    cursor = conn.cursor()

    cursor.execute(
        "SELECT message, times, start_date, end_date FROM reminders WHERE session_id = ?",
        (session_id,)
    )
    rows = cursor.fetchall()
    conn.close()

    # ✅ DB 조회 로그
    #print(f"[DB 조회 결과 for {session_id}] {rows}")

    result = []
    for row in rows:
        drug_name = row[0]
        times_raw = row[1]
        start_date = row[2]
        end_date = row[3]

        try:
            time_list = ast.literal_eval(times_raw) if times_raw else []
        except Exception as e:
            print(f"[시간 파싱 실패] 원본: {times_raw}, 오류: {e}")
            time_list = []

        for time in time_list:
            result.append({
                "drug_name": drug_name,
                "time_slot": time,
                "start_date": start_date,
                "end_date": end_date
            })

    return result


def get_all_session_ids():
    conn = sqlite3.connect("reminder.db")
    cursor = conn.cursor()

    cursor.execute("SELECT DISTINCT session_id FROM reminders")
    rows = cursor.fetchall()
    conn.close()

    return [row[0] for row in rows]
