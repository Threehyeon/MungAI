import re

def convert_wsl_path_to_windows(path):
    if path.startswith("/mnt/c/"):
        return path.replace("/mnt/c/", "C:/")
    return path


def sanitize_filename(text):
    return re.sub(r'[\\/:*?"<>|]', '', text)


# =======================
# 📄 utils/history_utils.py (12부)
# =======================
import os
import time

session_histories = {}
session_last_active = {}


def load_history(session_id):
    if os.path.exists(f"history_{session_id}.txt"):
        with open(f"history_{session_id}.txt", "r", encoding="utf-8") as f:
            return f.read().strip()
    return ""


def append_to_history(session_id, user_input, ai_response):
    if session_id not in session_histories:
        session_histories[session_id] = []
    session_histories[session_id].append((user_input, ai_response))
    if len(session_histories[session_id]) > 3:
        session_histories[session_id].pop(0)
    session_last_active[session_id] = time.time()

    existing_pairs = []
    path = f"history_{session_id}.txt"
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            lines = [line.strip() for line in f if line.strip()]
            for i in range(0, len(lines), 2):
                existing_pairs.append((lines[i][5:], lines[i+1][3:]))

    existing_pairs.append((user_input, ai_response))
    if len(existing_pairs) > 20:
        existing_pairs = existing_pairs[-20:]

    with open(path, "w", encoding="utf-8") as f:
        for u, a in existing_pairs:
            f.write(f"사용자: {u}\nAI: {a}\n")


def restore_session_histories():
    for filename in os.listdir("."):
        if filename.startswith("history_") and filename.endswith(".txt"):
            session_id = filename[len("history_"):-len(".txt")]
            with open(filename, "r", encoding="utf-8") as f:
                lines = [line.strip() for line in f][-8:]
                history_pairs, temp = [], []
                for line in lines:
                    if line.startswith("사용자: "):
                        temp = [line[5:].strip()]
                    elif line.startswith("AI: ") and temp:
                        temp.append(line[3:].strip())
                        if len(temp) == 2:
                            history_pairs.append(tuple(temp))
                            temp = []
                session_histories[session_id] = history_pairs
                session_last_active[session_id] = time.time()


def session_cleanup_task():
    while True:
        now = time.time()
        expired = [sid for sid, last in session_last_active.items() if now - last > 3600]
        for sid in expired:
            print(f"[CLEANUP] 세션 {sid} 만료, 메모리 제거")
            session_histories.pop(sid, None)
            session_last_active.pop(sid, None)
        time.sleep(600)


def log_emotion(session_id, timestamp, text, emotions):
    log_dir = "/mnt/c/Users/leesh/Desktop/zonos tts py/EmotionResult"
    os.makedirs(log_dir, exist_ok=True)
    log_file = os.path.join(log_dir, f"emotion_log_{session_id}.csv")
    is_new = not os.path.exists(log_file)
    labels = ['기쁨','슬픔','불안','분노','혐오','두려움','희망']
    with open(log_file, "a", encoding="utf-8") as f:
        if is_new:
            f.write("timestamp,text," + ",".join(labels) + "\n")
        scores = [str(round(emotions.get(label, 0.0), 4)) for label in labels]
        clean_text = text.replace(",", " ").replace("\n", " ")
        f.write(f"{timestamp},{clean_text}," + ",".join(scores) + "\n")
