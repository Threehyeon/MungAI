import sqlite3
import time

def get_safe_connection(db_path, retries=5, delay=0.1):
    for _ in range(retries):
        try:
            conn = sqlite3.connect(db_path, timeout=10)
            return conn
        except sqlite3.OperationalError as e:
            if "database is locked" in str(e):
                time.sleep(delay)
            else:
                raise
    raise sqlite3.OperationalError("database is locked (after retries)")


def init_user_db():
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id TEXT PRIMARY KEY,
            password TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()


def init_log_db():
    conn = sqlite3.connect('user_logs.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT NOT NULL,
            action TEXT NOT NULL,
            timestamp TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()


def log_user_action(user_id, action):
    conn = get_safe_connection('user_logs.db')
    cursor = conn.cursor()
    timestamp = time.strftime("%Y-%m-%dT%H:%M:%S")
    cursor.execute("INSERT INTO logs (user_id, action, timestamp) VALUES (?, ?, ?)", (user_id, action, timestamp))
    conn.commit()
    conn.close()
