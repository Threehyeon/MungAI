import os
import time
import sqlite3
import datetime

session_histories = {}
session_last_active = {}

HISTORY_DIR = "session_histories"

def restore_session_histories():
    print("[INIT] 세션 히스토리 복구 시작")
    if not os.path.exists(HISTORY_DIR):
        os.makedirs(HISTORY_DIR)

    for filename in os.listdir(HISTORY_DIR):
        if filename.startswith("history_") and filename.endswith(".txt"):
            session_id = filename[len("history_"):-len(".txt")]
            with open(os.path.join(HISTORY_DIR, filename), "r", encoding="utf-8") as f:
                lines = [line.strip() for line in f if line.strip()]

            history_pairs = []
            temp_pair = []

            for line in lines:
                if line.startswith("### 사용자:"):
                    temp_pair = [line.replace("### 사용자:", "").strip()]
                elif line.startswith("### AI:") and temp_pair:
                    temp_pair.append(line.replace("### AI:", "").strip())
                    if len(temp_pair) == 2:
                        history_pairs.append(tuple(temp_pair))
                        temp_pair = []

            session_histories[session_id] = history_pairs
            session_last_active[session_id] = time.time()

    print("[INIT] 세션 히스토리 복구 완료")


def load_history(session_id):
    """포맷된 히스토리 문자열 반환"""
    history_pairs = session_histories.get(session_id, [])
    history_text = ""
    for user, ai in history_pairs:
        history_text += f"### 사용자:\n{user}\n\n### 챗봇:\n{ai}\n\n"
    return history_text


def append_to_history(session_id, user_text, ai_text):
    """세션 히스토리 추가 및 파일 저장"""
    history = session_histories.get(session_id, [])
    history.append((user_text, ai_text))
    session_histories[session_id] = history[-1:]  # 최근 1개 유지
    session_last_active[session_id] = time.time()

    os.makedirs(HISTORY_DIR, exist_ok=True)
    filepath = os.path.join(HISTORY_DIR, f"history_{session_id}.txt")
    with open(filepath, "w", encoding="utf-8") as f:
        for user, ai in session_histories[session_id]:
            f.write(f"### 사용자: {user}\n")
            f.write(f"### AI: {ai}\n")


def session_cleanup_task():
    """1시간 이상 비활성 세션 정리"""
    while True:
        now = time.time()
        expired = [sid for sid, t in session_last_active.items() if now - t > 3600]
        for sid in expired:
            print(f"[CLEANUP] 세션 {sid} 만료됨. 제거")
            session_histories.pop(sid, None)
            session_last_active.pop(sid, None)
        time.sleep(600)


def log_user_action(user_id, action):
    """로그 기록"""
    conn = sqlite3.connect('user_logs.db')
    cursor = conn.cursor()
    timestamp = datetime.datetime.now().isoformat()
    cursor.execute(
        "INSERT INTO logs (user_id, action, timestamp) VALUES (?, ?, ?)",
        (user_id, action, timestamp)
    )
    conn.commit()
    conn.close()


def log_emotion(session_id, timestamp, text, emotion):
    """감정 분석 결과를 텍스트 파일로 저장"""
    os.makedirs("output", exist_ok=True)
    filename = f"output/emotion_{session_id}.txt"
    with open(filename, "a", encoding="utf-8") as f:
        f.write(f"[{timestamp}] {text} => 감정: {emotion}\n")
