import os
import json
import torch
import torchaudio
from datetime import datetime
from app.models.init_models import zonos_model
from app.services.tts_utils import get_cached_embedding, save_embedding

EMBEDDING_DIR = "app/cache/embeddings"
USER_REF_DIR = "ref_voices"
LATEST_TTS_DIR = "app/cache/latest_tts"
STATIC_AUDIO_DIR = "static/tts_audio"

# 디렉토리 초기화
os.makedirs(EMBEDDING_DIR, exist_ok=True)
os.makedirs(USER_REF_DIR, exist_ok=True)
os.makedirs(LATEST_TTS_DIR, exist_ok=True)
os.makedirs(STATIC_AUDIO_DIR, exist_ok=True)

async def generate_tts(session_id: str, text: str) -> str:
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    pitch_std_value, energy_value = 1.0, 1.0

    #  화자 임베딩 로드 또는 생성
    path = os.path.join(EMBEDDING_DIR, f"{session_id}.pt")
    if os.path.exists(path):
        speaker_embedding = torch.load(path, map_location="cuda").to("cuda")
    else:
        uploaded_ref_path = os.path.join(USER_REF_DIR, f"{session_id}.wav")
        if os.path.exists(uploaded_ref_path):
            ref_wav_tensor, ref_sr = torchaudio.load(uploaded_ref_path)
        else:
            default_path = "/mnt/c/Users/leesh/Desktop/zonos tts py/new/girl1.wav"
            ref_wav_tensor, ref_sr = torchaudio.load(default_path)

        zonos_model.to("cuda")
        speaker_embedding = zonos_model.make_speaker_embedding(ref_wav_tensor, ref_sr).to("cuda")
        torch.save(speaker_embedding.detach().cpu(), path)
        zonos_model.to("cpu")

    #  조건 생성
    cond = {
        "espeak": {"texts": [text], "languages": ["ko"]},
        "speaker": speaker_embedding.to(dtype=torch.bfloat16),
        "language_id": torch.tensor([[[0]]], dtype=torch.long).to("cuda"),
        "pitch_std": torch.tensor([[[pitch_std_value]]], dtype=torch.bfloat16).to("cuda"),
        "energy": torch.tensor([[[energy_value]]], dtype=torch.bfloat16).to("cuda")
    }

    #  TTS 생성
    zonos_model.to("cuda")
    prefix = zonos_model.prepare_conditioning(cond)
    max_steps = max(1600, min(2600, len(text) * 40))
    codes = zonos_model.generate(
        prefix_conditioning=prefix,
        max_new_tokens=max_steps,
        cfg_scale=7.0,
        sampling_params={"top_k": 50, "top_p": 0.95, "min_p": 0.1},
        disable_torch_compile=True,
        progress_bar=False
    )
    audio = zonos_model.autoencoder.decode(codes.to("cuda")).cpu().float()
    zonos_model.to("cpu")

    #  끝에 무음 1초 추가
    audio = torch.cat([audio, torch.zeros((1, 1, int(44100 * 1.0)))], dim=2)

    #  파일 경로 설정
    filename = f"reminder_{session_id}_{timestamp}.wav"
    pc_dir = "/mnt/c/Users/leesh/Desktop/zonos tts py/soundresult"
    web_path = os.path.join(STATIC_AUDIO_DIR, filename)
    pc_path = os.path.join(pc_dir, filename)

    os.makedirs(pc_dir, exist_ok=True)

    #  저장 (int16)
    audio_int16 = (audio.squeeze(0).clamp(-1, 1) * 32767).to(torch.int16)
    torchaudio.save(pc_path, audio_int16, 44100, encoding="PCM_S", bits_per_sample=16)
    torchaudio.save(web_path, audio_int16, 44100, encoding="PCM_S", bits_per_sample=16)

    #  최신 정보 기록 (→ Unity polling용)
    latest_info_path = os.path.join(LATEST_TTS_DIR, f"{session_id}.json")
    with open(latest_info_path, "w") as f:
        json.dump({
            "ready": True,
            "session_id": session_id,
            "timestamp": timestamp
        }, f)

    #  추가된 부분: .done 파일 생성 (Unity에서 상태 확인용)
    done_path = f"tts_reminder_{session_id}_{timestamp}.done"
    with open(done_path, "w") as f:
        f.write("done")

    # .txt 파일 생성 (wav 경로 저장용)
    txt_path = f"tts_reminder_{session_id}_{timestamp}.txt"
    with open(txt_path, "w", encoding="utf-8") as f:
        f.write(web_path)  # 또는 pc_path, Unity에서 요청하는 쪽에 맞춰서


    torch.cuda.empty_cache()
    return timestamp
