import torch
from app.models.init_models import kobert3_tokenizer, kobert3_model, kobert8_tokenizer, kobert8_model

kobert8_labels = ['공포', '놀람', '분노', '슬픔', '혐오', '기쁨', '신뢰', '기대']


async def analyze_emotion_dual(text):
    inputs_3 = kobert3_tokenizer(text, return_tensors="pt", truncation=True, padding=True).to("cpu")
    with torch.no_grad():
        outputs_3 = kobert3_model(**inputs_3)
        probs_3 = torch.softmax(outputs_3.logits, dim=1).squeeze()
        label_3 = ["negative", "neutral", "positive"][torch.argmax(probs_3).item()]

    inputs_8 = kobert8_tokenizer(text, return_tensors="pt", truncation=True, padding=True).to("cpu")
    with torch.no_grad():
        outputs_8 = kobert8_model(**inputs_8)
        probs_8 = torch.softmax(outputs_8.logits, dim=1).squeeze()
        refined = {label: float(score) for label, score in zip(kobert8_labels, probs_8)}

    return label_3, refined


async def refine_emotions_with_text(text, emotions):
    text = text.lower()
    default_keys = ['기쁨', '슬픔', '불안', '분노', '혐오', '공포', '희망', '놀람', '신뢰', '기대']
    for k in default_keys:
        if k not in emotions:
            emotions[k] = 0.0

    emotion_keywords = {
        "기쁨": ["기쁘다", "좋다", "웃었다", "설렌다", "행복"],
        "슬픔": ["슬프다", "울고", "외롭다", "눈물", "우울"],
        "불안": ["불안", "긴장", "초조", "걱정"],
        "분노": ["화난다", "짜증", "열받아", "분노"],
        "혐오": ["역겨워", "싫다", "혐오"],
        "공포": ["무섭다", "공포", "소름"],
        "희망": ["희망", "기대된다", "해볼만해"]
    }

    detected = set()
    for emotion, keywords in emotion_keywords.items():
        if any(kw in text for kw in keywords):
            detected.add(emotion)
            if emotions.get(emotion, 0.0) < 0.2:
                emotions[emotion] += 0.12

    if emotions.get("놀람", 0.0) < 0.13:
        emotions["놀람"] = 0.0

    emotions = normalize_emotions(emotions)
    return emotions, detected


def normalize_emotions(emotions):
    emotions = {k: (v if v >= 0.003 else 0.0) for k, v in emotions.items()}
    total = sum(emotions.values())
    if total > 0:
        emotions = {k: v / total for k, v in emotions.items()}
    return emotions


def refine_main_emotions(emotion_scores, text=None):
    adjusted = emotion_scores.copy()
    if "혐오" in adjusted:
        adjusted["혐오"] = max(0.0, adjusted["혐오"] - 0.015)
    if "공포" in adjusted and adjusted["공포"] < 0.16:
        adjusted["공포"] = max(0.0, adjusted["공포"] - 0.01)
    sorted_emotions = sorted(adjusted.items(), key=lambda x: x[1], reverse=True)
    return sorted_emotions[0][0] if sorted_emotions else None


def generate_emotion_prompt(emotions: dict, label_3: str = None):
    main_emotions = sorted(emotions.items(), key=lambda x: x[1], reverse=True)[:2]
    if len(main_emotions) >= 2 and abs(main_emotions[0][1] - main_emotions[1][1]) < 0.015:
        return "사용자의 감정이 명확하지 않아. 중립적인 말투로 조심스럽게 반응해줘."

    descriptions = {
        "슬픔": "슬플 때는 조심스럽고 부드럽게 위로운 말투로 말해줘.",
        "기쁨": "기쁠 때는 따뜻하고 신나게 기뻐하는 말투로 말해줘",
        "분노": "화를 느낄 때는 차분히 이해하는 말투로 말해줘.",
        "혐오": "혐오를 느낄 땐 이해심 있는 말투로 말해줘",
        "공포": "무서움을 느낄 땐 안심시키는 말투로 말해줘",
        "놀람": "놀라운 상황은 긍정적으로 받아들이는 말투로 말해줘.",
        "신뢰": "신뢰에는 존중과 따뜻함으로 반응하는 말투로 말해줘",
        "기대": "기대에는 희망차고 긍정적인 말투로 말해줘" 
    }

    prompt_parts = []
    if label_3 == "positive":
        prompt_parts.append("대화 분위기가 밝아요. 부드럽고 따뜻하게 말해줘.")
    elif label_3 == "negative":
        prompt_parts.append("대화 분위기가 무거워요. 조심스럽고 다정하게 말해줘.")

    for emo, _ in main_emotions:
        prompt_parts.append(descriptions.get(emo, f"사용자는 {emo} 감정을 느끼고 있어. 다정하게 반응해줘."))

    return " ".join(prompt_parts)