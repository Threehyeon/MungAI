import os
import shutil
import traceback
import torch
import torchaudio

from transformers import AutoTokenizer
from app.models.init_models import whisper_model, zonos_model
from app.services.chatbot_service import generate_response_with_emotion
from app.services.emotion_service import analyze_emotion_dual, refine_emotions_with_text
from app.utils.history_utils import log_emotion

#  전역 tokenizer 선언 (최상단에서 1회만 로드)
tokenizer = AutoTokenizer.from_pretrained("heegyu/polyglot-ko-1.3b-chat", trust_remote_code=True)

EMBEDDING_DIR = "app/cache/embeddings"
USER_REF_DIR = "ref_voices"
os.makedirs(EMBEDDING_DIR, exist_ok=True)
os.makedirs(USER_REF_DIR, exist_ok=True)

def get_cached_embedding(session_id):
    path = os.path.join(EMBEDDING_DIR, f"{session_id}.pt")
    if os.path.exists(path):
        return torch.load(path, map_location="cuda")
    return None

def save_embedding(session_id, embedding):
    path = os.path.join(EMBEDDING_DIR, f"{session_id}.pt")
    torch.save(embedding.detach().cpu(), path)

async def handle_whisper_background(file_path, session_id, timestamp):
    try:
        result = whisper_model.transcribe(file_path, fp16=torch.cuda.is_available(), language='ko')
        text = result['text']
        no_speech_prob = result.get('no_speech_prob', 0)
        print(f"\n[WHISPER] 🗣️ 인식된 사용자 음성: \"{text.strip()}\"\n")
        torch.cuda.empty_cache()

        if not text.strip() or len(text.strip()) <= 3 or no_speech_prob > 0.5:
            response = "죄송해요, 잘 들리지 않았어요. 다시 말씀해주시겠어요?"
            emotion = None
        else:
            _, emotion = await analyze_emotion_dual(text)
            emotion, _ = await refine_emotions_with_text(text, emotion)
            log_emotion(session_id, timestamp, text, emotion)
            response = await generate_response_with_emotion(text, emotion, session_id)
            llm_output_dir = "llm_outputs"
            os.makedirs(llm_output_dir, exist_ok=True)
            llm_output_path = os.path.join(llm_output_dir, f"{session_id}_{timestamp}.txt")
            with open(llm_output_path, "w", encoding="utf-8") as f:
                f.write(response)

        pitch_std_value, energy_value = 1.0, 1.0
        if emotion:
            if emotion.get('슬픔', 0) > 0.6:
                pitch_std_value, energy_value = 0.95, 0.8
            elif emotion.get('기쁨', 0) > 0.6:
                pitch_std_value, energy_value = 1.2, 1.3
            elif emotion.get('불안', 0) > 0.6:
                pitch_std_value, energy_value = 0.9, 0.9
            elif emotion.get('분노', 0) > 0.6:
                pitch_std_value, energy_value = 1.0, 1.5

        speaker_embedding = get_cached_embedding(session_id)
        if speaker_embedding is None:
            print(f"[DEBUG] 🔄 {session_id} 임베딩 캐시 없음, 새로 생성 중...")
            uploaded_ref_path = os.path.join(USER_REF_DIR, f"{session_id}.wav")
            if os.path.exists(uploaded_ref_path):
                print(f"[DEBUG] ✅ 사용자 업로드 ref_wav 사용: {uploaded_ref_path}")
                ref_wav_tensor, ref_sr = torchaudio.load(uploaded_ref_path)
            else:
                print(f"[DEBUG] ⚠️ 사용자 업로드 없음 → 기본 목소리 사용")
                default_path = "/mnt/c/Users/leesh/Desktop/zonos tts py/new/girl1.wav"
                ref_wav_tensor, ref_sr = torchaudio.load(default_path)

            zonos_model.to("cuda")
            speaker_embedding = zonos_model.make_speaker_embedding(ref_wav_tensor, ref_sr).to("cuda")
            save_embedding(session_id, speaker_embedding)
            zonos_model.to("cpu")
        else:
            speaker_embedding = speaker_embedding.to("cuda")

        cond = {
            "espeak": {
                "texts": [response],
                "languages": ["ko"]
            },
            "speaker": speaker_embedding.to(dtype=torch.bfloat16),
            "language_id": torch.tensor([[[0]]], dtype=torch.long).to("cuda"),
            "pitch_std": torch.tensor([[[pitch_std_value]]], dtype=torch.bfloat16).to("cuda"),
            "energy": torch.tensor([[[energy_value]]], dtype=torch.bfloat16).to("cuda")
        }

        zonos_model.to("cuda")
        prefix = zonos_model.prepare_conditioning(cond)
        text_length = len(response)
        max_steps = max(1600, min(2600, text_length * 40))
        prefix = zonos_model.prepare_conditioning(cond)

        codes = zonos_model.generate(
            prefix_conditioning=prefix,
            max_new_tokens=max_steps,
            cfg_scale=7.0,
            sampling_params={"top_k": 50, "top_p": 0.95, "min_p": 0.1},
            disable_torch_compile=True,
            progress_bar=False
        )

        audio = zonos_model.autoencoder.decode(codes.to("cuda")).cpu().float()
        zonos_model.to("cpu")

        padding = torch.zeros((1, 1, int(44100 * 1.0)))
        audio = torch.cat([audio, padding], dim=2)

        linux_output_dir = "/home/leesh/soyo_tts/soundresult"
        windows_output_dir = "/mnt/c/Users/leesh/Desktop/zonos tts py/soundresult"
        os.makedirs(linux_output_dir, exist_ok=True)
        os.makedirs(windows_output_dir, exist_ok=True)
        filename = f"response_{session_id}_{timestamp}.wav"

        linux_path = os.path.join(linux_output_dir, filename)
        audio_int16 = (audio.squeeze(0).clamp(-1, 1) * 32767).to(torch.int16)
        torchaudio.save(linux_path, audio_int16, 44100, encoding="PCM_S", bits_per_sample=16)

        windows_path = os.path.join(windows_output_dir, filename)
        shutil.copy(linux_path, windows_path)
        os.sync()
        
        with open(f"tts_chat_{session_id}_{timestamp}.txt", "w", encoding="utf-8") as f:
            f.write(linux_path)
        with open(f"tts_chat_{session_id}_{timestamp}.done", "w") as f:
            f.write("done")


        torch.cuda.empty_cache()

    except Exception as e:
        print("[ERROR][WHISPER TASK]", e)
        traceback.print_exc()
