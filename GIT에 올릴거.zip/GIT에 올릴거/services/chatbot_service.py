from app.utils.history_utils import load_history, append_to_history
from app.models.init_models import tokenizer, llm
import torch
import time

# 자살 발화 필터링
SUICIDE_KEYWORDS = ["죽고 싶어", "자살", "끝내고 싶어", "살기 싫어", "괴로워", "없어지고 싶어"]

def detect_dangerous_text(text):
    return any(keyword in text for keyword in SUICIDE_KEYWORDS)

async def generate_response_with_emotion(text, emotion=None, session_id=None):
    history = load_history(session_id) if session_id else ""

    if detect_dangerous_text(text):
        response = "당신의 이야기를 듣고 있어요. 주변 도움도 생각해봐요. 당신은 소중한 존재입니다."
        if session_id:
            append_to_history(session_id, text, response)
        return response
    
    #  감정 분석은 TTS에만 적용하므로 여기선 주석 처리
    # label_3, emotion_scores_8 = await analyze_emotion_dual(text)
    # emotions, detected = await refine_emotions_with_text(text, emotion_scores_8)
    # main_emotion = refine_main_emotions(emotions, text)
    # style_hint = generate_emotion_prompt({main_emotion: emotions[main_emotion]}, label_3)
    # mood_hint = f"전체적으로 이 문장은 '{label_3}' 분위기를 가지고 있어. 이 점을 고려해서 답변해줘."

    
    prompt = (
        "당신은 AI 챗봇입니다. 사용자에게 도움이 되고 유익한 내용을 제공해야 합니다. "
        "답변은 길고 자세하며 친절한 설명을 덧붙여서 작성하세요.\n\n"
        f"{history}"
        f"### 사용자:\n{text}\n\n"
        "### 챗봇:"
    )

    print(f"\n[DEBUG] 🔍 LLM 입력 프롬프트:\n{prompt}\n")

    # LLM 추론
    llm.to("cuda")
    inputs = tokenizer(prompt, return_tensors="pt", padding=True).to("cuda")
    inputs.pop("token_type_ids", None)

    # 히스토리가 길 경우 자르기
    if inputs["input_ids"].shape[1] > 3500:
        inputs["input_ids"] = inputs["input_ids"][:, -3500:]
        if "attention_mask" in inputs:
            inputs["attention_mask"] = inputs["attention_mask"][:, -3500:]

    start = time.time()
    outputs = llm.generate(
        **inputs,
        max_new_tokens=200,
        min_length=120,
        do_sample=True,
        top_k=60,
        top_p=0.92,
        temperature=0.72,
        no_repeat_ngram_size=2,
        repetition_penalty=1.2
    )
    print(f"[DEBUG] LLM 생성 소요시간: {time.time() - start:.2f}초")
    llm.to("cpu")

    decoded = tokenizer.decode(outputs[0], skip_special_tokens=True).strip()

    # 응답 정제
    if "챗봇:" in decoded:
        decoded = decoded.split("챗봇:")[-1].strip()
    for stop_token in ["사용자:", "시스템:", "Assistant:", "User:"]:
        if stop_token in decoded:
            decoded = decoded.split(stop_token)[0].strip()

    final = decoded
    if len(final) > 500:
        final = final[:500].rsplit(".", 1)[0] + "."

    response = final if final.strip() not in ["...", "…", ""] else "다시 한번 말해주세요."
    print(f"[DEBUG] ✅ 최종 응답:\n{response}")

    if session_id:
        append_to_history(session_id, text, response)

    return response
