import os
import json
from datetime import datetime
from fastapi import APIRouter, Query
from fastapi.responses import JSONResponse, FileResponse
from app.utils.file_utils import convert_wsl_path_to_windows

router = APIRouter()


@router.get("/reminder-tts-status")
async def reminder_tts_status(session_id: str = Query(...), timestamp: str = Query(...)):
    txt_path = convert_wsl_path_to_windows(f"tts_reminder_{session_id}_{timestamp}.txt")
    done_path = convert_wsl_path_to_windows(f"tts_reminder_{session_id}_{timestamp}.done")

    print(f"[SERVER] 상태 확인 요청: session_id={session_id}, timestamp={timestamp}")
    print(f"[SERVER] txt 경로: {txt_path} 존재 여부: {os.path.exists(txt_path)}")
    print(f"[SERVER] done 경로: {done_path} 존재 여부: {os.path.exists(done_path)}")

    if os.path.exists(txt_path) and os.path.exists(done_path):
        print("[SERVER] TTS 파일 준비 완료")
        return {"ready": True}
    
    print("[SERVER] TTS 파일 아직 준비되지 않음")
    return {"ready": False}


@router.get("/reminder-tts-audio")
async def reminder_tts_audio(session_id: str = Query(...), timestamp: str = Query(...)):
    txt_path = convert_wsl_path_to_windows(f"tts_reminder_{session_id}_{timestamp}.txt")
    print(f"[SERVER] 오디오 요청: session_id={session_id}, timestamp={timestamp}")
    print(f"[SERVER] txt 파일 경로: {txt_path}")

    if not os.path.exists(txt_path):
        print("[SERVER] .txt 파일 없음")
        return JSONResponse(content={"error": "TTS 경로 없음"}, status_code=404)

    with open(txt_path, "r", encoding="utf-8") as f:
        audio_path = f.read().strip()

    print(f"[SERVER] 오디오 경로 (txt에서 읽음): {audio_path}")
    print(f"[SERVER] .wav 존재 여부: {os.path.exists(audio_path)}")

    if not os.path.exists(audio_path):
        print("[SERVER] .wav 파일 없음")
        return JSONResponse(content={"error": "파일 없음"}, status_code=404)

    print("[SERVER] 오디오 파일 전송 시작")
    return FileResponse(
        path=audio_path,
        media_type="audio/wav",
        filename=os.path.basename(audio_path)
    )


@router.get("/check-reminders")
async def check_reminders(session_id: str = Query(...)):
    latest_info_path = convert_wsl_path_to_windows(f"app/cache/latest_tts/{session_id}.json")

    print(f"[SERVER] 알림 확인 요청: session_id={session_id}")

    if not os.path.exists(latest_info_path):
        print("[SERVER] 최신 TTS 정보 없음")
        return JSONResponse(content={"ready": False})

    with open(latest_info_path, "r", encoding="utf-8") as f:
        info = json.load(f)
        timestamp = info.get("timestamp")

    txt_path = convert_wsl_path_to_windows(f"tts_reminder_{session_id}_{timestamp}.txt")
    done_path = convert_wsl_path_to_windows(f"tts_reminder_{session_id}_{timestamp}.done")

    print(f"[SERVER] 경로 확인: {txt_path}, {done_path}")

    if os.path.exists(txt_path) and os.path.exists(done_path):
        print("[SERVER] 알림 TTS 준비 완료")
        return JSONResponse(content={
            "ready": True,
            "timestamp": timestamp
        })

    print("[SERVER] 준비된 알림 TTS 없음")
    return JSONResponse(content={"ready": False})

@router.post("/reminder-played")
async def reminder_played(session_id: str = Query(...), timestamp: str = Query(...)):
    done_path = convert_wsl_path_to_windows(f"tts_reminder_{session_id}_{timestamp}.done")

    if os.path.exists(done_path):
        os.remove(done_path)
        print(f"[SERVER] .done 파일 삭제됨: {done_path}")
        return {"success": True, "message": "done 파일 삭제 완료"}
    
    return {"success": False, "message": "done 파일 없음"}


