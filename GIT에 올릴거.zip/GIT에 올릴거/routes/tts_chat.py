import os
from fastapi import APIRouter, Query
from fastapi.responses import JSONResponse, FileResponse
from app.utils.file_utils import convert_wsl_path_to_windows

router = APIRouter()

@router.get("/chat-tts-status")
async def chat_tts_status(session_id: str = Query(...), timestamp: str = Query(...)):
    txt_path = convert_wsl_path_to_windows(f"tts_chat_{session_id}_{timestamp}.txt")
    done_path = convert_wsl_path_to_windows(f"tts_chat_{session_id}_{timestamp}.done")

    print(f"[SERVER] 상태 확인 요청: session_id={session_id}, timestamp={timestamp}")
    print(f"[SERVER] txt_path: {txt_path}")
    print(f"[SERVER] done_path: {done_path}")

    if os.path.exists(txt_path) and os.path.exists(done_path):
        print("[SERVER] TTS 파일 준비 완료")
        return {"ready": True}

    print("[SERVER] TTS 파일 아직 준비되지 않음")
    return {"ready": False}


@router.get("/chat-tts-audio")
async def chat_tts_audio(session_id: str = Query(...), timestamp: str = Query(...)):
    txt_path = convert_wsl_path_to_windows(f"tts_chat_{session_id}_{timestamp}.txt")
    print(f"[SERVER] 오디오 요청: session_id={session_id}, timestamp={timestamp}")
    print(f"[SERVER] txt_path: {txt_path}")

    if not os.path.exists(txt_path):
        print("[SERVER] .txt 파일 없음")
        return JSONResponse(content={"error": "TTS 경로 없음"}, status_code=404)

    with open(txt_path, "r", encoding="utf-8") as f:
        linux_audio_path = f.read().strip()

    windows_audio_path = convert_wsl_path_to_windows(linux_audio_path)

    print(f"[SERVER] audio_path from txt (linux): {linux_audio_path}")
    print(f"[SERVER] converted to windows path: {windows_audio_path}")

    if not os.path.exists(windows_audio_path):
        print("[SERVER] .wav 파일 없음")
        return JSONResponse(content={"error": "파일 없음"}, status_code=404)

    print("[SERVER] TTS 오디오 파일 전송 시작")
    return FileResponse(
        path=windows_audio_path,
        media_type="audio/wav",
        filename=os.path.basename(windows_audio_path)
    )


