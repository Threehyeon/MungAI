from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from app.utils.database import get_safe_connection
from app.utils.history_utils import log_user_action
import sqlite3

router = APIRouter()

class User(BaseModel):
    id: str
    password: str

@router.post("/register")
async def register_user(user: User):
    try:
        conn = get_safe_connection('users.db')
        cursor = conn.cursor()

        cursor.execute("SELECT * FROM users WHERE id = ?", (user.id,))
        if cursor.fetchone():
            conn.close()
            raise HTTPException(status_code=409, detail="이미 존재하는 ID입니다.")

        cursor.execute("INSERT INTO users (id, password) VALUES (?, ?)", (user.id, user.password))
        conn.commit()
        conn.close()

        try:
            log_user_action(user.id, "register")
        except Exception as log_err:
            print("[WARN][REGISTER] 로그 기록 오류:", log_err)

        return {"success": True, "message": "회원가입 성공"}

    except sqlite3.IntegrityError:
        raise HTTPException(status_code=409, detail="이미 존재하는 ID입니다.")
    except Exception as e:
        print("[ERROR][REGISTER]", e)
        raise HTTPException(status_code=500, detail="서버 내부 오류")


@router.post("/login")
async def login_user(user: User):
    conn = get_safe_connection('users.db')
    cursor = conn.cursor()

    cursor.execute("SELECT password FROM users WHERE id = ?", (user.id,))
    row = cursor.fetchone()
    conn.close()

    if row and row[0] == user.password:
        log_user_action(user.id, "login")
        return {"success": True, "session_id": user.id}
    else:
        raise HTTPException(status_code=401, detail="로그인 실패")