# app/routes/tts.py
from fastapi import APIRouter

router = APIRouter()

@router.get("/tts-test")
async def tts_test():
    return {"message": "🔊 TTS 라우터 정상 작동 중"}
