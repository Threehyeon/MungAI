from fastapi import APIRouter, HTTPException, Query
from app.models.reminder_model import ReminderRequest
import sqlite3
import traceback
import json
import os

router = APIRouter()
DB_PATH = "reminder.db"


@router.post("/add-reminder")
async def add_reminder(data: ReminderRequest):
    try:
        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()

        # 테이블 생성
        cur.execute("""
            CREATE TABLE IF NOT EXISTS reminders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT,
                message TEXT,
                times TEXT,
                start_date TEXT,
                end_date TEXT,
                voice_type TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        times_str = json.dumps(data.times) if data.times else "[]"

        cur.execute("""
            INSERT INTO reminders (session_id, message, times, start_date, end_date, voice_type)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (
            data.session_id,
            data.message,
            times_str,
            data.start_date,
            data.end_date,
            data.voice_type
        ))

        conn.commit()
        conn.close()

        return {"status": "ok", "msg": "Reminder saved successfully"}

    except Exception as e:
        print("❌ add-reminder 오류:", traceback.format_exc())
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/check-reminders")
async def check_reminders(session_id: str = Query(...)):
    try:
        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()

        cur.execute("""
            SELECT message, times, start_date, end_date, voice_type
            FROM reminders
            WHERE session_id = ?
        """, (session_id,))

        rows = cur.fetchall()
        print(f"📦 [check_reminders] rows: {rows}")
        conn.close()

        result = []
        for row in rows:
            times = json.loads(row[1]) if row[1] else []
            result.append({
                "message": row[0],
                "times": times,
                "start_date": row[2],
                "end_date": row[3],
                "voice_type": row[4]
            })
        print(f"✅ [check_reminders] 반환할 result: {result}")
        return result  # 항상 리스트 형태로 반환

    except Exception as e:
        print("❌ check-reminders 오류:", traceback.format_exc())
        raise HTTPException(status_code=500, detail="서버 내부 오류가 발생했습니다.")


@router.get("/latest-tts")
async def get_latest_tts(session_id: str = Query(...)):
    path = f"app/cache/latest_tts/{session_id}.json"

    if os.path.exists(path):
        with open(path, "r") as f:
            data = json.load(f)
        return data
    else:
        return {"ready": False, "message": "No TTS generated yet"}
