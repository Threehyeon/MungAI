from fastapi import APIRouter, Query, HTTPException
from fastapi.responses import HTMLResponse
import pandas as pd
import matplotlib.pyplot as plt
from io import BytesIO
import base64
import os

router = APIRouter()

@router.get("/emotion-graph-summary", response_class=HTMLResponse)
async def emotion_graph_summary(session_id: str = Query(...)):
    csv_path = f"/mnt/c/Users/leesh/Desktop/zonos tts py/EmotionResult/emotion_log_{session_id}.csv"
    if not os.path.exists(csv_path):
        raise HTTPException(status_code=404, detail="해당 감정 로그가 존재하지 않습니다")

    df = pd.read_csv(csv_path)
    df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms", errors='coerce')
    df = df.dropna(subset=["timestamp"])
    df.set_index("timestamp", inplace=True)

    target_emotions = ["행복", "슬픔", "불안", "분노", "혐오", "두려움", "희망"]
    if df[target_emotions].dropna(how="all").empty:
        return "감정 데이터가 없습니다."

    mean_values = df[target_emotions].mean().sort_values(ascending=True)

    plt.figure(figsize=(8, 4))
    mean_values.plot(kind="barh", color="skyblue")
    plt.title(f"전체 평균 감정 분포 - 세션 {session_id}")
    plt.xlabel("점수")
    plt.tight_layout()

    img_buf = BytesIO()
    plt.savefig(img_buf, format="png")
    plt.close()
    img_buf.seek(0)

    img_base64 = base64.b64encode(img_buf.read()).decode("utf-8")
    html = f'<img src="data:image/png;base64,{img_base64}" style="max-width:100%;">'
    return HTMLResponse(content=html)
