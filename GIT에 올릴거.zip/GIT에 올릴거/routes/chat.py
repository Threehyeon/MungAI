from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from app.services.chatbot_service import generate_response_with_emotion

router = APIRouter()

class ChatRequest(BaseModel):
    text: str
    session_id: str = None

@router.post("/chat")
async def chat_endpoint(request: ChatRequest):
    if not request.text.strip():
        raise HTTPException(status_code=400, detail="text 파라미터 없음")

    response = generate_response_with_emotion(request.text, request.session_id)
    return {"response": response}