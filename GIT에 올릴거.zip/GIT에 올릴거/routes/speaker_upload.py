from fastapi import APIRouter, UploadFile, Form
import os
import shutil

router = APIRouter()

@router.post("/upload-recorded-ref-wav")
async def upload_recorded_ref_wav(
    session_id: str = Form(...),
    ref_wav: UploadFile = Form(...)
):
    try:
        #  디렉토리 생성 보장
        ref_dir = "ref_voices"
        embed_dir = "app/cache/embeddings"
        os.makedirs(ref_dir, exist_ok=True)
        os.makedirs(embed_dir, exist_ok=True)

        #  파일 저장
        save_path = os.path.join(ref_dir, f"{session_id}.wav")
        with open(save_path, "wb") as f:
            shutil.copyfileobj(ref_wav.file, f)
        print(f"[UPLOAD]  녹음된 화자 음성 저장 완료: {save_path}")

        # 🧹 기존 임베딩 삭제
        embedding_path = os.path.join(embed_dir, f"{session_id}.pt")
        if os.path.exists(embedding_path):
            os.remove(embedding_path)
            print(f"[CLEANUP] 기존 임베딩 삭제됨: {embedding_path}")

        return {"success": True, "message": "녹음 파일 저장 및 임베딩 리셋 완료"}

    except Exception as e:
        print("[ERROR][UPLOAD RECORDED REF WAV]", e)
        return {"success": False, "message": str(e)}
